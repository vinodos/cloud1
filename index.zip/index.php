<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo '<p>Hello World   VERSION 2 </p>'; ?> 
 </body>
</html>
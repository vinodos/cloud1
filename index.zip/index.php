<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo '<p>Hello World   VERSION 333</p>'; ?> 
 </body>
</html>